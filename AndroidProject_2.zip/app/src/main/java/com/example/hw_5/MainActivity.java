package com.example.hw_5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private boolean isSub = false;
    private View mainLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainLayout = findViewById(R.id.mainLayout);

        String profileName = "@alecsander";
        setTitle("Профиль пользователя: " + profileName);

        Button btSub = findViewById(R.id.btSub);
        btSub.setOnClickListener(view -> {
            if (isSub) {
                Snackbar snackbar = Snackbar.make(view, "Вы точно хотите отписаться?", Snackbar.LENGTH_SHORT);
                snackbar.setAction("Да", view1 -> {
                    btSub.setBackgroundColor(getResources().getColor(R.color.subscribe_bt_color));
                    btSub.setText("Подписаться");
                    isSub = false;
                });
                snackbar.show();
            } else {
                btSub.setBackgroundColor(getResources().getColor(R.color.not_subscribe_bt_color));
                btSub.setText("Отписаться");
                isSub = true;

                Toast toast = Toast.makeText(getApplicationContext(), "Вы успешно подписались", Toast.LENGTH_SHORT);
                toast.show();
            }
        });

        Button btChangeColor = findViewById(R.id.btChangeColor);
        btChangeColor.setOnClickListener(view -> {
            changeBackColor();
        });
    }

    private void changeBackColor() {
        Random random = new Random();
        int color = android.graphics.Color.rgb(random.nextInt(256),random.nextInt(256),random.nextInt(256));
        mainLayout.setBackgroundColor(color);
    }
}